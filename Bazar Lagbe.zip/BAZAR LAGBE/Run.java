import java.lang.*;
import interfaces.*;
import classes.*;
public class Run
{

	public static void main(String[] args)
	{
		new Login();
	}

}
