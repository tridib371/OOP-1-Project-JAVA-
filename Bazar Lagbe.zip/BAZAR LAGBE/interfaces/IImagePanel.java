package interfaces;
import java.lang.*;
import classes.*;
import java.awt.Graphics;
import java.awt.Image;

public interface IImagePanel
{
	void paintComponent(Graphics g);
}
