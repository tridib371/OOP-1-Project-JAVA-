package interfaces;
import java.lang.*;
import classes.*;
import java.awt.event.ActionEvent;

public interface IPaymentSuccess
{
	void actionPerformed(ActionEvent e);
}
