package interfaces;
import java.lang.*;
import classes.*;
import java.awt.event.ActionEvent;
public interface ILogin 
{
	void actionPerformed(ActionEvent e);
}
