package interfaces;
import java.lang.*;
import classes.*;
import java.awt.event.ActionEvent;

public interface IFish
{
	void actionPerformed(ActionEvent e);
}
