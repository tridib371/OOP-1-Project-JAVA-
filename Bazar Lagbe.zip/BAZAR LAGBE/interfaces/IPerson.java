package interfaces;
import java.lang.*;
import classes.*;
public interface IPerson
{
	String getName();
	String getAge();
}
