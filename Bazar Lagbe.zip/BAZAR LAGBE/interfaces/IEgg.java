package interfaces;
import java.lang.*;
import classes.*;
import java.awt.event.ActionEvent;

public interface IEgg
{
	void actionPerformed(ActionEvent e);
}
