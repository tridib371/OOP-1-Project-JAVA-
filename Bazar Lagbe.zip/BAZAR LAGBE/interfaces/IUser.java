package interfaces;
import java.lang.*;
import classes.*;

public interface IUser
{
	String getPassword();
}